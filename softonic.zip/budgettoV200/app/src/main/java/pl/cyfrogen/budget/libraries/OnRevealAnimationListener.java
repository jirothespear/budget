package pl.cyfrogen.budget.libraries;


public interface OnRevealAnimationListener {
    void onRevealHide();
    void onRevealShow();
}
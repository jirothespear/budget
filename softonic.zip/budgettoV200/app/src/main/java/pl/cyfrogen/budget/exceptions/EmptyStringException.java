package pl.cyfrogen.budget.exceptions;

public class EmptyStringException extends Exception {
    public EmptyStringException(String text) {
        super(text);
    }
}

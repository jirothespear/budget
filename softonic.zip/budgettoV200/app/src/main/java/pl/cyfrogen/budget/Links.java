package pl.cyfrogen.budget;

public class Links {
    public static String PRIVACY_POLICY_LINK="https://policies.google.com/privacy?hl=en-US";
}
